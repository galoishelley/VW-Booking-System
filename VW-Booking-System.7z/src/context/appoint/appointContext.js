import { createContext } from 'react';

const appointContext = createContext();

export default appointContext;
