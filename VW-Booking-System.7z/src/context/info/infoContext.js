import { createContext } from 'react';

const infoContext = createContext();

export default infoContext;
