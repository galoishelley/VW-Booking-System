import React, { useState, useContext, useEffect } from 'react'
import InfoContext from '../../context/info/infoContext';

const InfoForm = () => {
    const infoContext = useContext(InfoContext);

    // const { fname,lname,phone,email } = infoContext;

    // useEffect(() => {
    //     if (current !== null) {
    //         setContact(current);
    //     } else {
    //         setContact({
    //             name: '',
    //             email: '',
    //             phone: '',
    //             address: '',
    //             type: 'personal'
    //         });
    //     }
    // }, [infoContext, current])

    const [info, setInfo] = useState({
        fname: '',
        lname: '',
        phone: '',
        email: ''
    });

    console.log(info);

    const { fname, lname, phone, email } = info;

    const onChange = e => setInfo({ ...info, [e.target.name]: e.target.value });

    const onSubmit = e => {
        e.preventDefault();
        // if (current === null) {
        //     // addContact(contact);
        // } else {
        //     // updateContact(contact);
        // }
        console.log('submit');
    };

    // const clearAll = () => {
    //     clearCurrent();
    // }

    return (
        <form onSubmit={onSubmit}>
            <label htmlFor="name">Name</label><span> *</span>
            <input type="text" placeholder='First Name' name='fname' value={fname} onChange={onChange} />
            <input type="text" placeholder='Last Name' name='lname' value={lname} onChange={onChange} />
            <label htmlFor="phone">Phone</label>
            <input type="text" placeholder='Phone' name='phone' value={phone} onChange={onChange} />
            <label htmlFor="email">Email</label><span> *</span>
            <input type="email" placeholder='Email' name='email' value={email} onChange={onChange} />
            <div>
                <input type="submit" value='Complete Appointment >>' className="btn btn-dark btn-block" />
            </div>
        </form>
    )
}

export default InfoForm
