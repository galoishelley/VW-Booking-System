import React, { useState, useContext, useEffect } from 'react'
import InfoForm from './infoForm';

const Info = () => {
    return (
        <div className='Info'>
            <h5>chiro 30 minutes@ $100.00</h5>
            <h6>Change</h6>
            <InfoForm />
        </div>
    )
}

export default Info;
