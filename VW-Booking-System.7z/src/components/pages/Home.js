import React from 'react';
// import Appointment from '../appointments/Appointment';

const Home = () => {
    // const authContext = useContext(AuthContext);

    // useEffect(()=>{
    //     authContext.loadUser();
    // },[])

    return (
        <div className="apointmentlist">
            <span>nihaoj</span>
              {/* <Appointment /> */}
        </div>

    )
}

export default Home;
