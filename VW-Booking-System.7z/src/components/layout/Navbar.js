import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';

const Navbar = ({ title, instruction }) => {
    return (
        <div className="navbar">
            <h1 className="large">
               {title}
            </h1>
            <p>{instruction}</p>
            <ul>
                <li>
                    <Link to="/">Choose Appointment</Link>
                </li>
                <li>
                    <Link to="/info">Your Info</Link>
                </li>
                <li>
                    <Link to="/comfirm">Comfirmation</Link>
                </li>
            </ul>
        </div>
    )
}

Navbar.propTypes = {
    title: PropTypes.string.isRequired
}

Navbar.defaultProps = {
    title: 'Book a wellness session.',
    instruction:'Visit one of our expert consultants to get yourself feeling 100% again.'
}

export default Navbar;