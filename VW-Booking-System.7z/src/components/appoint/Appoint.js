import React, { Fragment, useContext } from 'react';
import AppointItem from './appointItem';
import AppointContext from '../../context/appoint/appointContext';


const Appoint = () => {

    const appointContext = useContext(AppointContext);

    const { items } = appointContext;

    if (items.length === 0) {
        return <h4>Please add appointment List</h4>
    }

    console.log(items);

    return (
        <Fragment>
            {items.map(item => (
                <AppointItem item={item} />
            ))}
        </Fragment>
    )
}

export default Appoint;