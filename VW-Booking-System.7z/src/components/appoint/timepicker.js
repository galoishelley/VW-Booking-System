import React, { useContext,useEffect } from 'react';
import AppointContext from '../../context/appoint/appointContext';

const Timepicker = (selectDate) => {

    const appointContext = useContext(AppointContext);
    const { timeArr, currentItem, selectedTime, yourSelectTime } = appointContext;

    const onChange = e =>({});
    var tmpTime =  new Array(timeArr);



    useEffect(() => {
        


        console.log("start");
        console.log(selectedTime);
        console.log("end");

        const occupied__slots= selectedTime;
        for(let i=0; i<occupied__slots.length; i++){
            const index = tmpTime[0].indexOf("4:00pm");
                if (index > -1) {
                    tmpTime[0].splice(index, 1);
                }
        }

        //eslint-disable-next-line
    }, [selectDate,selectedTime]);

    return (
        <div className="Timepicker">
            <ul>
                { 
                    tmpTime[0].map(time =>(
                        <li key={time}><input type="radio" name="time" onChange={onChange} />{ time}</li>
                    ))
                    
                }
            </ul>
        </div>
    );
}

export default Timepicker;