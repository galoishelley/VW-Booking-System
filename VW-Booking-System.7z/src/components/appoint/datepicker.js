import React, { Fragment, useState, useContext } from 'react';
import DatePicker,{ registerLocale }  from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { subDays, format,getYear,getMonth,addMonths,subMonths} from "date-fns";
import AppointContext from '../../context/appoint/appointContext';
import Timepicker from './timepicker';

const Datepicker = () => {

    const appointContext = useContext(AppointContext);
    const { orderedates, timeArr, showDataPicker,currentItem,setSelectedTime,selectedTime} = appointContext;

    const { date, time } = orderedates;
   
    // console.log('Datepicker1'+ currentItem);


    const excludeDates =[];

    var arrAppoint =  new Array();
   

    var display="hide";

    const getDate = () =>{ 
        let map = new Map();
        let array = new Array(); 
        let arrTime = new Array();
        

        //Remove duplicate data
        for (let i = 0; i < orderedates.length; i++) {
            if(map.has(orderedates[i].date)) {  
              map.set(orderedates[i].date, true); 
            } else { 
              map.set(orderedates[i].date, false);  
              array.push(orderedates[i].date);
            }
        }

        // console.log('ddddddd1');
        // console.log(array);
        // console.log('ddddddd2');

        //check time
        
        for(let j = 0; j < array.length; j++){
            arrTime=[];
            for (let i = 0; i < orderedates.length; i++) {
                if(orderedates[i].date === array[j]) {  
                    arrTime.push(orderedates[i].time)
                } 
            }

            arrAppoint.push({date:array[j],time:arrTime})
            // console.log('=========b3');
            // console.log(arrTime);
            // console.log(arrAppoint);
            // console.log('=========e3');


            if( JSON.stringify(arrTime) === JSON.stringify(timeArr))
            {
                excludeDates.push(new Date(array[j]));
            }
        }

        // console.log('=========b');
        // console.log(excludeDates);
        // console.log('=========e');

        //check time
        // JSON.stringify(array3) === JSON.stringify(array4)
        // timeArr 

        // orderedates.push(new Date(array[i].date));
        

    };

    getDate();

    const formatDate = (date) => {
      var d = new Date(date),
          month = '' + (d.getMonth() + 1),
          day = '' + d.getDate(),
          year = d.getFullYear();
  
      if (month.length < 2) 
          month = '0' + month;
      if (day.length < 2) 
          day = '0' + day;
  
      // return [year, month, day].join('-');
      return [month, day, year].join('-');
  }

    const [startDate, setStartDate] = useState(new Date());
    const [minDate, setMinDate] = useState(new Date());
    const [maxDate, setMaxDate] = useState(addMonths(new Date(), 6));
    // const [excludeDates, setExcludeDates] = useState(new Date('2021/08/5'));

    const [selectDate, setSelectDate] = useState(new Date());
    
    const handleCheckInDate = (date) => {

        display="show";

        setSelectDate(date);
        

        let fData = formatDate(date);
        let currentClickDate =  new Array();
       

        for (let i = 0; i < arrAppoint.length; i++) {
          if(arrAppoint[i].date === fData) {  
            currentClickDate.push(arrAppoint[i].time);
          }
      }

      console.log("alex:0000:"+currentClickDate[0]);
      

      setSelectedTime(currentClickDate);
      console.log(selectedTime);

      
    };

    console.log("alex:11111100:"+selectedTime);
    console.log(selectedTime);

    const handleCheckOutDate = (date) => {
      // setCheckOutDate(date);
    };

      

    // const years = range(1990, getYear(new Date()) + 1, 1);
    const years = ['2021','2022'] ;
    const months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ];

    return (
        <div className={showDataPicker}>
    <DatePicker
      renderCustomHeader={({
        date,
        changeYear,
        changeMonth,
        decreaseMonth,
        increaseMonth,
        prevMonthButtonDisabled,
        nextMonthButtonDisabled,
      }) => (
        <div
          style={{
            margin: 10,
            display: "flex",
            justifyContent: "center",
          }}
        >
          <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
            {"<"}
          </button>
          <select
            value={getYear(date)}
            onChange={({ target: { value } }) => changeYear(value)}
          >
            {years.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>

          <select
            value={months[getMonth(date)]}
            onChange={({ target: { value } }) =>
              changeMonth(months.indexOf(value))
            }
          >
            {months.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>

          <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
            {">"}
          </button>
        </div>
      )}
        selected={startDate}
        onChange={(date) => setStartDate(date)}
        minDate={minDate}
        excludeDates={excludeDates}
        onChange={handleCheckInDate}
      />

        <div>
            <h4>please select a time</h4>
            <Timepicker selectDate={selectDate}/>
        </div>
      </div>
    );
}

export default Datepicker;