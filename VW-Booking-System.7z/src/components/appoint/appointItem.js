
import React, { useContext } from 'react'
import PropTypes from 'prop-types';
import AppointContext from '../../context/appoint/appointContext';
import Datepicker from './datepicker';


const AppointItem = ({ item }) => {

    
    const appointContext = useContext(AppointContext);
    const { setCurrentItem, setShowDataPicker,showDataPicker,currentItem } = appointContext;
    const { spaname, spatime } = item;

    const setItem = () => {
        setCurrentItem(spaname);
        setShowDataPicker(true);
    }
    
    return (
        <div>
            <div className='card bg-light' onClick={setItem}>
               <ul className="list">
                    {spaname && (
                        <li>
                            {spaname}
                        </li>
                    )}

                    {spatime && (
                        <li>
                            {spatime}
                        </li>
                    )}
                </ul>
            </div>
            
            {showDataPicker && <div>
                <Datepicker />
            </div>}
        </div>
    )
}

AppointItem.propTypes = {
    appointment: PropTypes.object.isRequired,
 }

export default AppointItem;
