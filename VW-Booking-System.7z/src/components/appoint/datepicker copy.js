import React, { Fragment, useState } from 'react';
import DatePicker,{ registerLocale }  from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { subDays, format,getYear,getMonth,addMonths,subMonths} from "date-fns";

const Datepicker = () => {

    var monthsInEng = ["January","February","March","April","May", "June", "July","August", "September", "October", "November", "December"];
    var months = [];
    var years = [];
    var data = new Date();
    var year = data.getFullYear();
    data.setMonth(data.getMonth(), 1)//获取到当前月份,设置月份
    for (var i = 0; i < 12; i++) {
        var tm = data.getMonth() 
        var td = monthsInEng[tm];
        // months.push(td + " " + data.getFullYear());
        months.push(td);
        years.push(data.getFullYear());

        var m = data.getMonth() + 1 ;
        m = m < 10 ? "0" + m : m;
        
        data.setMonth(data.getMonth() + 1);//每次循环一次 月份值减1
    }
 


    const [startDate, setStartDate] = useState(new Date());
    const [minDate, setMinDate] = useState(new Date('2021/08/5'));
    const [maxDate, setMaxDate] = useState(addMonths(new Date(), 6));
    const [excludeDates, setExcludeDates] = useState(new Date('2021/08/5'));
    console.log('2230233232begin');
    console.log(excludeDates);

    // var formattedDate = format(new Date("2016-01-04 10:34:23"), "MMMM do, yyyy H:mma");

    // console.log(formattedDate);

    console.log('2230233232end');
    // const years = range(1990, getYear(new Date()) + 1, 1);
    // const years = ['2021','2022'] ;
    // const months = [
    //     "January",
    //     "February",
    //     "March",
    //     "April",
    //     "May",
    //     "June",
    //     "July",
    //     "August",
    //     "September",
    //     "October",
    //     "November",
    //     "December",
    // ];

    // const months = dataArr;


    console.log(months);

    return (
        <DatePicker
        renderCustomHeader={({
          date,
          changeMonth,
          decreaseMonth,
          increaseMonth,
          prevMonthButtonDisabled,
          nextMonthButtonDisabled,
        }) => (
          <div
            style={{
              margin: 10,
              display: "flex",
              justifyContent: "center",
            }}
          >
            <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
              {"<"}
            </button>
          
            <select
              value={months[getMonth(date)]}
              onChange={({ target: { value } }) =>
                changeMonth(months.indexOf(value))
              }
            >
              {months.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
  
            <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
              {">"}
            </button>
          </div>
        )}
        selected={startDate}
        onChange={(date) => setStartDate(date)}
        shouldCloseOnSelect={false}
        excludeDates={[excludeDates]}
      />
    );
}

export default Datepicker;