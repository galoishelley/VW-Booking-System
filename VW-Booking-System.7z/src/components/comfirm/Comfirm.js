import React from 'react';
import ResultMsg from './resultMsg';
import ShowQR from './showQR';

const Comfirm = () => {
    return (
        <div className="grid-2">
            <div>
                <ResultMsg />
            </div>
            <div>
                <ShowQR />
            </div>
        </div>
    )
}

export default Comfirm;
