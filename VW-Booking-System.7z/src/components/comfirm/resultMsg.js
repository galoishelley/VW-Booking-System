import React from 'react';

const resultMsg = () => {
    return (
        <div>
            <h1>Aroma Therapy</h1>
            <h2>Thursday,July 22, 2021 12:00PM</h2>
            <h4>Veyor Wellness $45.00</h4>
            <div>
                <input type="submit" value='Cancel' className="btn btn-dark btn-block" />
                <input type="submit" value='Reschedule' className="btn btn-dark btn-block" />
            </div>
            <div>
                <input type="submit" value='Schedule another Appointment' className="btn btn-block" />
                {/* <i class="fas fa-angle-double-right"></i> */}
            </div>
        </div>
    )
}

export default resultMsg;
